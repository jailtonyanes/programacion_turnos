<?php
 include('../_include/configuration.php');
 include('../_classes/conectar.php');
include('../_classes/crud.php');
include('../_include/configuration.php'); 

?>
  